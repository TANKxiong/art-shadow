@echo off
cd /d "%~dp0"
echo 画影客 - 启动中...
echo.

:: Start HTTP server from dist folder
start "ArtShadowServer" /B npx.cmd --yes serve dist --listen 5800 --no-clipboard --single

timeout /t 2 /nobreak >nul

:: Open in Chrome app mode
start "ArtShadow" chrome --app=http://localhost:5800 --window-size=1400,900 --user-data-dir="%TEMP%\art-shadow"

echo 画影客已启动！关闭此窗口即可退出。
pause
